
# web based KYC solution 

a simple web based KYC solution in python(flask)/javascript where a user can record his audio/video and save on server in the best compression algorithm

First install the flask module if not install using the command :

pip install flask


after that run the app.py file it will create a server 

open browser and type : http://127.0.0.1:5000

click on start recording button and then stop after your video complete 

video will saved into downloads folder .

Thank You